<?php

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => 'eD72XrG5o4vPDZc6D7C1t12bD7NKXy6NHLO6MeTghsUcH', // Your API Key from https://killbot.org/developer
    'bot_redirect'  => '404' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];