<html class="light  content-size-medium  next"><head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="msapplication-TileColor" content="#ffffff">
<meta name="msapplication-TileImage" content="images/global/favicon/favicon-96x96.png"><title>Verification</title>
	<meta name="description" content="Comcast Identity Management Portal">
	<meta name="author" content="Comcast">
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0">


<link rel="stylesheet" href="https://idm.xfinity.com/myaccount/dist/vendor/prism-ui/prism-ui.css">








<link rel="stylesheet" href="https://idm.xfinity.com/myaccount/dist/bundle.css">


<link rel="stylesheet" type="text/css" href="https://cdn.comcast.com/cmp/css/cookie-consent.css">
	<script type="text/javascript" src="https://cdn-prod.securiti.ai/consent/auto_blocking/4b9bbe2a-9c5d-4512-bb76-768a8ea32bc0/a76cdf55-ebf2-44a8-890a-2b5167b45b18.js"></script><script type="tracking-data-digitalData">
	{
		"page": {
			"category": {
		"primaryCategory": "IDM",
		"subCategory1": "reset",
		
		"businessType": "resi",
		"siteType": "selfservice",
		"designType": "responsive"
	},
			"codebase" : {
				"name": "cima idm",
				"releaseVersion": ""
			}
		},
		
			"transaction": {
				"attributes": {
					"flowStage": "in-progress"
				}
			},
		
		"affiliate" : {
			"name": "comcast",
			"channel": "web"
		},
		"schemaVersion": 0.18
	}
</script>

	<script type="tracking-data-page">
		{
		
			"pageInfo": {
				"screenName": "password reset - Enter Reset Code",
				"language": "en",
				"referrerId": "default"
			}
		
		
		
	}
	</script>


	<script type="tracking-data-user">
		[{
		"profile": [{
			"attributes": {
				"resetVerificationMethod":"sms"
			}
		}]
	}]
	</script>


<script>
	document.addEventListener("DOMContentLoaded", function() {
		document.dispatchEvent(new CustomEvent("c-tracking-log-page", {
			bubbles: true
		}));
	});
</script><script type="text/plain" src="https://static.cimcontent.net/data-layer/?appId=idm" data-cookiecategory="77"></script>
		<style id="xc-header-styles">@font-face {
font-family: 'XfinityBrown';

src: url('https://static.cimcontent.net/common-web-assets/fonts/xfinity-brown-optimized/xfinitybrown-bold.woff2') format('woff2'), url('https://static.cimcontent.net/common-web-assets/fonts/xfinity-brown-optimized/xfinitybrown-bold.woff') format('woff'), url('https://static.cimcontent.net/common-web-assets/fonts/xfinity-brown-optimized/xfinitybrown-bold.ttf') format('truetype');

font-weight: 700;

font-style: normal;
}

@font-face {
font-family: 'DMSans';

src: url('https://static.cimcontent.net/common-web-assets/fonts/dm-sans/dmsans-regular.woff2') format('woff2'), url('https://static.cimcontent.net/common-web-assets/fonts/dm-sans/dmsans-regular.woff') format('woff');

font-weight: 400;

font-style: normal;
}

@font-face {
font-family: 'DMSans';

src: url('https://static.cimcontent.net/common-web-assets/fonts/dm-sans/dmsans-medium.woff2') format('woff2'), url('https://static.cimcontent.net/common-web-assets/fonts/dm-sans/dmsans-medium.woff') format('woff');

font-weight: 500;

font-style: normal;
}

html {
font-family: DMSans, Helvetica, sans-serif;
}

:root {
--shadow-color: rgb(0 0 0 / 50%);
--text-display0-family: var(--text-family-brand);
--text-display0-size: 2.25000rem;
--text-display0-line-height: 2.81250rem;
--text-display0-weight: 700;
--text-display0-letter-spacing: -0.4px;
--text-display0-text-transform: none;
--text-display1-family: var(--text-family-brand);
--text-display1-size: clamp(2rem, calc(1.82143rem + 0.89286vw), 2.25rem);
--text-display1-line-height: clamp(2.5rem, calc(2.27679rem + 1.11607vw), 2.8125rem);
--text-display1-weight: 700;
--text-display1-letter-spacing: -0.4px;
--text-display1-text-transform: none;
--text-display2-family: var(--text-family-brand);
--text-display2-size: clamp(1.75rem, calc(1.57143rem + 0.89286vw), 2rem);
--text-display2-line-height: clamp(2.1875rem, calc(1.96429rem + 1.11607vw), 2.5rem);
--text-display2-weight: 700;
--text-display2-letter-spacing: -0.4px;
--text-display2-text-transform: none;
--text-headline1-family: var(--text-family-brand);
--text-headline1-size: 1.50000rem;
--text-headline1-line-height: 2.00000rem;
--text-headline1-weight: 700;
--text-headline1-letter-spacing: -0.2px;
--text-headline1-text-transform: none;
--text-headline2-family: var(--text-family-brand);
--text-headline2-size: 1.25000rem;
--text-headline2-line-height: 1.50000rem;
--text-headline2-weight: 700;
--text-headline2-letter-spacing: -0.2px;
--text-headline2-text-transform: none;
--text-headline3-family: var(--text-family-brand);
--text-headline3-size: 1.00000rem;
--text-headline3-line-height: 1.50000rem;
--text-headline3-weight: 700;
--text-headline3-letter-spacing: 0px;
--text-headline3-text-transform: none;
--text-body0-family: var(--text-family-default);
--text-body0-size: 1.00000rem;
--text-body0-line-height: 1.50000rem;
--text-body0-weight: 400;
--text-body0-letter-spacing: 0px;
--text-body0-text-transform: none;
--text-body1-family: var(--text-family-default);
--text-body1-size: 1.00000rem;
--text-body1-line-height: 1.50000;
--text-body1-weight: 400;
--text-body1-letter-spacing: 0px;
--text-body1-text-transform: none;
--text-body2-family: var(--text-family-default);
--text-body2-size: 0.87500rem;
--text-body2-line-height: 1.50000;
--text-body2-weight: 400;
--text-body2-letter-spacing: 0px;
--text-body2-text-transform: none;
--text-body3-family: var(--text-family-default);
--text-body3-size: 0.87500rem;
--text-body3-line-height: 1.50000;
--text-body3-weight: 400;
--text-body3-letter-spacing: 0px;
--text-body3-text-transform: none;
--text-body4-family: var(--text-family-default);
--text-body4-size: 0.87500rem;
--text-body4-line-height: 1.50000;
--text-body4-weight: 400;
--text-body4-letter-spacing: 0px;
--text-body4-text-transform: none;
--text-button1-family: var(--text-family-brand);
--text-button1-size: 1.00000rem;
--text-button1-line-height: 1.50000;
--text-button1-weight: 700;
--text-button1-letter-spacing: 0px;
--text-button1-text-transform: none;
--text-button2-family: var(--text-family-brand);
--text-button2-size: 0.87500rem;
--text-button2-line-height: 1.71429;
--text-button2-weight: 700;
--text-button2-letter-spacing: 0px;
--text-button2-text-transform: none;
--text-callout1-family: var(--text-family-default);
--text-callout1-size: 0.87500rem;
--text-callout1-line-height: 1.50000;
--text-callout1-weight: 400;
--text-callout1-letter-spacing: 1px;
--text-callout1-text-transform: uppercase;
--text-callout2-family: var(--text-family-default);
--text-callout2-size: 0.75000rem;
--text-callout2-line-height: 1.33333;
--text-callout2-weight: 400;
--text-callout2-letter-spacing: 1px;
--text-callout2-text-transform: uppercase;
--text-caption-family: var(--text-family-default);
--text-caption-size: 0.75000rem;
--text-caption-line-height: 1.33333;
--text-caption-weight: 400;
--text-caption-letter-spacing: 0px;
--text-caption-text-transform: none;
--text-tag-family: var(--text-family-default);
--text-tag-size: 0.62500rem;
--text-tag-line-height: 1.20000;
--text-tag-weight: 500;
--text-tag-letter-spacing: 0px;
--text-tag-text-transform: none;
--text-family-brand: XfinityBrown, DMSans, Helvetica, sans-serif;
--text-family-default: DMSans, Helvetica, sans-serif;
--fill-caution-base-shadow: rgba(95,29,0,0.51);
--fill-caution-down-shadow: rgba(74,22,0,0.51);
--fill-caution-focus-shadow: rgba(85,26,0,0.51);
--fill-caution-hover-shadow: rgba(85,26,0,0.51);
--fill-info-base-shadow: rgba(0,39,112,0.51);
--fill-info-down-shadow: rgba(0,24,68,0.51);
--fill-info-focus-shadow: rgba(0,30,85,0.51);
--fill-info-hover-shadow: rgba(0,30,85,0.51);
--fill-inverse-base-shadow: rgba(135,135,136,0.51);
--fill-inverse-down-shadow: rgba(111,111,118,0.51);
--fill-inverse-focus-shadow: rgba(140,140,140,0.51);
--fill-inverse-hover-shadow: rgba(140,140,140,0.51);
--fill-negative-base-shadow: rgba(97,1,28,0.51);
--fill-negative-down-shadow: rgba(51,0,14,0.51);
--fill-negative-focus-shadow: rgba(74,0,21,0.51);
--fill-negative-hover-shadow: rgba(74,0,21,0.51);
--fill-neutral-base-shadow: rgba(8,8,10,0.51);
--fill-neutral-down-shadow: rgba(34,34,39,0.51);
--fill-neutral-focus-shadow: rgba(24,24,28,0.51);
--fill-neutral-hover-shadow: rgba(24,24,28,0.51);
--fill-positive-base-shadow: rgba(0,52,39,0.51);
--fill-positive-down-shadow: rgba(0,23,18,0.51);
--fill-positive-focus-shadow: rgba(0,40,30,0.51);
--fill-positive-hover-shadow: rgba(0,40,30,0.51);
--fill-theme1-base-shadow: rgba(48,26,134,0.51);
--fill-theme1-down-shadow: rgba(18,0,48,0.51);
--fill-theme1-focus-shadow: rgba(27,0,75,0.51);
--fill-theme1-hover-shadow: rgba(27,0,75,0.51);
--material-1-shadow: rgba(140,140,140,0.51);
--material-2-shadow: rgba(135,135,136,0.51);
--material-1-inverse-shadow: rgba(8,8,10,0.51);
--material-2-inverse-shadow: rgba(15,15,18,0.51);
--material-caution-shadow: rgba(132,122,117,0.51);
--material-caution-inverse-shadow: rgba(27,14,8,0.51);
--material-info-shadow: rgba(117,122,132,0.51);
--material-info-inverse-shadow: rgba(8,13,24,0.51);
--material-negative-shadow: rgba(132,117,122,0.51);
--material-negative-inverse-shadow: rgba(22,7,12,0.51);
--material-positive-shadow: rgba(117,132,127,0.51);
--material-positive-inverse-shadow: rgba(6,19,14,0.51);
--material-theme1-shadow: rgba(123,121,133,0.51);
--material-theme1-inverse-shadow: rgba(12,9,26,0.51);
--material-neutral-base-shadow: rgba(140,140,140,0.51);
--material-neutral-down-shadow: rgba(121,121,121,0.51);
--material-neutral-focus-shadow: rgba(134,134,134,0.51);
--material-neutral-hover-shadow: rgba(134,134,134,0.51);
--material-neutral2-base-shadow: rgba(135,135,136,0.51);
--material-neutral2-down-shadow: rgba(117,117,118,0.51);
--material-neutral2-focus-shadow: rgba(129,129,130,0.51);
--material-neutral2-hover-shadow: rgba(129,129,130,0.51);
--material-caution-base-shadow: rgba(132,122,117,0.51);
--material-caution-down-shadow: rgba(115,106,102,0.51);
--material-caution-focus-shadow: rgba(126,117,112,0.51);
--material-caution-hover-shadow: rgba(126,117,112,0.51);
--material-info-base-shadow: rgba(117,122,132,0.51);
--material-info-down-shadow: rgba(102,106,115,0.51);
--material-info-focus-shadow: rgba(112,117,126,0.51);
--material-info-hover-shadow: rgba(112,117,126,0.51);
--material-negative-base-shadow: rgba(132,117,122,0.51);
--material-negative-down-shadow: rgba(115,102,106,0.51);
--material-negative-focus-shadow: rgba(126,112,117,0.51);
--material-negative-hover-shadow: rgba(126,112,117,0.51);
--material-positive-base-shadow: rgba(117,132,127,0.51);
--material-positive-down-shadow: rgba(102,115,111,0.51);
--material-positive-focus-shadow: rgba(112,126,122,0.51);
--material-positive-hover-shadow: rgba(112,126,122,0.51);
--material-neutral-inverse-base-shadow: rgba(8,8,10,0.51);
--material-neutral-inverse-down-shadow: rgba(22,22,23,0.51);
--material-neutral-inverse-focus-shadow: rgba(13,13,14,0.51);
--material-neutral-inverse-hover-shadow: rgba(13,13,14,0.51);
--material-neutral2-inverse-base-shadow: rgba(15,15,18,0.51);
--material-neutral2-inverse-down-shadow: rgba(29,29,31,0.51);
--material-neutral2-inverse-focus-shadow: rgba(20,20,22,0.51);
--material-neutral2-inverse-hover-shadow: rgba(20,20,22,0.51);
--material-caution-inverse-base-shadow: rgba(27,14,8,0.51);
--material-caution-inverse-down-shadow: rgba(39,28,22,0.51);
--material-caution-inverse-focus-shadow: rgba(31,18,13,0.51);
--material-caution-inverse-hover-shadow: rgba(31,18,13,0.51);
--material-info-inverse-base-shadow: rgba(8,13,24,0.51);
--material-info-inverse-down-shadow: rgba(21,27,37,0.51);
--material-info-inverse-focus-shadow: rgba(12,17,28,0.51);
--material-info-inverse-hover-shadow: rgba(12,17,28,0.51);
--material-negative-inverse-base-shadow: rgba(22,7,12,0.51);
--material-negative-inverse-down-shadow: rgba(35,21,25,0.51);
--material-negative-inverse-focus-shadow: rgba(27,12,16,0.51);
--material-negative-inverse-hover-shadow: rgba(27,12,16,0.51);
--material-positive-inverse-base-shadow: rgba(6,19,14,0.51);
--material-positive-inverse-down-shadow: rgba(19,32,28,0.51);
--material-positive-inverse-focus-shadow: rgba(10,23,19,0.51);
--material-positive-inverse-hover-shadow: rgba(10,23,19,0.51);
--material-theme1-base-shadow: rgba(123,121,133,0.51);
--material-theme1-down-shadow: rgba(107,105,116,0.51);
--material-theme1-focus-shadow: rgba(118,116,127,0.51);
--material-theme1-hover-shadow: rgba(118,116,127,0.51);
}

*, ::before, ::after {
--tw-translate-x: 0;
--tw-translate-y: 0;
--tw-rotate: 0;
--tw-skew-x: 0;
--tw-skew-y: 0;
--tw-scale-x: 1;
--tw-scale-y: 1;
--tw-pan-x:  ;
--tw-pan-y:  ;
--tw-pinch-zoom:  ;
--tw-scroll-snap-strictness: proximity;
--tw-ordinal:  ;
--tw-slashed-zero:  ;
--tw-numeric-figure:  ;
--tw-numeric-spacing:  ;
--tw-numeric-fraction:  ;
--tw-ring-inset:  ;
--tw-ring-offset-width: 0px;
--tw-ring-offset-color: #fff;
--tw-ring-color: rgb(59 130 246 / 0.5);
--tw-ring-offset-shadow: 0 0 #0000;
--tw-ring-shadow: 0 0 #0000;
--tw-shadow: 0 0 #0000;
--tw-shadow-colored: 0 0 #0000;
--tw-blur:  ;
--tw-brightness:  ;
--tw-contrast:  ;
--tw-grayscale:  ;
--tw-hue-rotate:  ;
--tw-invert:  ;
--tw-saturate:  ;
--tw-sepia:  ;
--tw-drop-shadow:  ;
--tw-backdrop-blur:  ;
--tw-backdrop-brightness:  ;
--tw-backdrop-contrast:  ;
--tw-backdrop-grayscale:  ;
--tw-backdrop-hue-rotate:  ;
--tw-backdrop-invert:  ;
--tw-backdrop-opacity:  ;
--tw-backdrop-saturate:  ;
--tw-backdrop-sepia:  ;
}

.xc-text-headline2 {
font-family: var(--text-headline2-family);
font-size: var(--text-headline2-size);
font-weight: var(--text-headline2-weight);
letter-spacing: var(--text-headline2-letter-spacing);
line-height: var(--text-headline2-leading);
text-transform: var(--text-headline2-text-transform);
--text-headline2-leading: var(--text-headline2-line-height);
--text-headline2-family: var(--text-family-brand);
}

.xc-text-headline3 {
font-family: var(--text-headline3-family);
font-size: var(--text-headline3-size);
font-weight: var(--text-headline3-weight);
letter-spacing: var(--text-headline3-letter-spacing);
line-height: var(--text-headline3-leading);
text-transform: var(--text-headline3-text-transform);
--text-headline3-leading: var(--text-headline3-line-height);
--text-headline3-family: var(--text-family-brand);
}

.xc-text-body1 {
font-family: var(--text-body1-family);
font-size: var(--text-body1-size);
font-weight: var(--text-body1-weight);
letter-spacing: var(--text-body1-letter-spacing);
line-height: var(--text-body1-leading);
text-transform: var(--text-body1-text-transform);
--text-body1-leading: var(--text-body1-line-height);
--text-body1-family: var(--text-family-default);
}

.xc-text-body2 {
font-family: var(--text-body2-family);
font-size: var(--text-body2-size);
font-weight: var(--text-body2-weight);
letter-spacing: var(--text-body2-letter-spacing);
line-height: var(--text-body2-leading);
text-transform: var(--text-body2-text-transform);
--text-body2-leading: var(--text-body2-line-height);
--text-body2-family: var(--text-family-default);
}

.xc-text-button1 {
font-family: var(--text-button1-family);
font-size: var(--text-button1-size);
font-weight: var(--text-button1-weight);
letter-spacing: var(--text-button1-letter-spacing);
line-height: var(--text-button1-leading);
text-transform: var(--text-button1-text-transform);
--text-button1-leading: var(--text-button1-line-height);
--text-button1-family: var(--text-family-brand);
}

.xc-text-button2 {
font-family: var(--text-button2-family);
font-size: var(--text-button2-size);
font-weight: var(--text-button2-weight);
letter-spacing: var(--text-button2-letter-spacing);
line-height: var(--text-button2-leading);
text-transform: var(--text-button2-text-transform);
--text-button2-leading: var(--text-button2-line-height);
--text-button2-family: var(--text-family-brand);
}

.xc-text-caption {
font-family: var(--text-caption-family);
font-size: var(--text-caption-size);
font-weight: var(--text-caption-weight);
letter-spacing: var(--text-caption-letter-spacing);
line-height: var(--text-caption-leading);
text-transform: var(--text-caption-text-transform);
--text-caption-leading: var(--text-caption-line-height);
--text-caption-family: var(--text-family-default);
}

.xc-fixed {
position: fixed;
}

.xc-absolute {
position: absolute;
}

.xc-relative {
position: relative;
}

.xc-inset-0 {
top: 0;
right: 0;
bottom: 0;
left: 0;
}

.xc-inset-y-0 {
top: 0;
bottom: 0;
}

.xc-left-0 {
left: 0;
}

.xc-top-0 {
top: 0;
}

.xc-top-4 {
top: 16px;
}

.xc-right-4 {
right: 16px;
}

.xc-left-4 {
left: 16px;
}

.xc-right-0 {
right: 0;
}

.xc-top-full {
top: 100%;
}

.xc-left-auto {
left: auto;
}

.xc-top-3 {
top: 12px;
}

.xc-right-3 {
right: 12px;
}

.xc-top-6 {
top: 24px;
}

.xc-left-6 {
left: 24px;
}

.xc-z-10 {
z-index: 10;
}

.xc-z-\[1000\] {
z-index: 1000;
}

.xc-z-\[999\] {
z-index: 999;
}

.xc--z-10 {
z-index: -10;
}

.xc-col-span-2 {
grid-column: span 2 / span 2;
}

.xc-m-0 {
margin: 0;
}

.xc-m-auto {
margin: auto;
}

.xc-my-3 {
margin-top: 12px;
margin-bottom: 12px;
}

.xc-mx-4 {
margin-left: 16px;
margin-right: 16px;
}

.xc-mx-auto {
margin-left: auto;
margin-right: auto;
}

.xc-my-0 {
margin-top: 0;
margin-bottom: 0;
}

.xc-mx-3 {
margin-left: 12px;
margin-right: 12px;
}

.xc-my-2 {
margin-top: 8px;
margin-bottom: 8px;
}

.xc--mx-2 {
margin-left: -8px;
margin-right: -8px;
}

.xc-mb-4 {
margin-bottom: 16px;
}

.xc-mb-2 {
margin-bottom: 8px;
}

.xc-mt-4 {
margin-top: 16px;
}

.xc-mr-4 {
margin-right: 16px;
}

.xc-mr-1 {
margin-right: 4px;
}

.xc--ml-3 {
margin-left: -12px;
}

.xc-mr-1\.5 {
margin-right: 6px;
}

.xc-mb-10 {
margin-bottom: 40px;
}

.xc-mt-6 {
margin-top: 24px;
}

.xc-mt-0 {
margin-top: 0;
}

.xc-mb-3 {
margin-bottom: 12px;
}

.xc-mt-8 {
margin-top: 32px;
}

.xc-mb-6 {
margin-bottom: 24px;
}

.xc-ml-3 {
margin-left: 12px;
}

.xc-mt-px {
margin-top: 1px;
}

.xc-ml-1 {
margin-left: 4px;
}

.xc-mb-8 {
margin-bottom: 32px;
}

.xc-box-border {
box-sizing: border-box;
}

.xc-block {
display: block;
}

.xc-inline-block {
display: inline-block;
}

.xc-flex {
display: flex;
}

.xc-inline-flex {
display: inline-flex;
}

.xc-grid {
display: grid;
}

.xc-hidden {
display: none;
}

.xc-h-6 {
height: 24px;
}

.xc-h-4 {
height: 16px;
}

.xc-h-16 {
height: 64px;
}

.xc-h-full {
height: 100%;
}

.xc-h-12 {
height: 48px;
}

.xc-h-auto {
height: auto;
}

.xc-h-\[72px\] {
height: 72px;
}

.xc-h-11 {
height: 44px;
}

.xc-h-14 {
height: 56px;
}

.xc-h-10 {
height: 40px;
}

.xc-h-8 {
height: 32px;
}

.xc-h-5 {
height: 20px;
}

.xc-w-full {
width: 100%;
}

.xc-w-6 {
width: 24px;
}

.xc-w-\[72px\] {
width: 72px;
}

.xc-w-4 {
width: 16px;
}

.xc-w-12 {
width: 48px;
}

.xc-w-10 {
width: 40px;
}

.xc-w-auto {
width: auto;
}

.xc-max-w-screen-xds1440 {
max-width: 1440px;
}

.xc-max-w-\[700px\] {
max-width: 700px;
}

.xc-origin-right {
transform-origin: right;
}

.xc--translate-x-80 {
--tw-translate-x: -320px;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-translate-x-full {
--tw-translate-x: 100%;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-rotate-180 {
--tw-rotate: 180deg;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-scale-x-0 {
--tw-scale-x: 0;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-scale-x-100 {
--tw-scale-x: 1;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-cursor-pointer {
cursor: pointer;
}

.xc-list-none {
list-style-type: none;
}

.xc-grid-cols-1 {
grid-template-columns: repeat(1, minmax(0, 1fr));
}

.xc-flex-wrap {
flex-wrap: wrap;
}

.xc-place-content-center {
place-content: center;
}

.xc-items-start {
align-items: flex-start;
}

.xc-items-center {
align-items: center;
}

.xc-items-baseline {
align-items: baseline;
}

.xc-justify-center {
justify-content: center;
}

.xc-justify-between {
justify-content: space-between;
}

.xc-overflow-auto {
overflow: auto;
}

.xc-overflow-hidden {
overflow: hidden;
}

.xc-rounded-small {
border-radius: 4px;
}

.xc-rounded-bl-medium {
border-bottom-left-radius: 8px;
}

.xc-rounded-br-medium {
border-bottom-right-radius: 8px;
}

.xc-border-0 {
border-width: 0px;
}

.xc-border {
border-width: 1px;
}

.xc-border-x-0 {
border-left-width: 0px;
border-right-width: 0px;
}

.xc-border-b {
border-bottom-width: 1px;
}

.xc-border-t-0 {
border-top-width: 0px;
}

.xc-border-t {
border-top-width: 1px;
}

.xc-border-solid {
border-style: solid;
}

.xc-border-stroke-inverse-down {
--tw-border-opacity: 1;
border-color: rgb(206 206 218 / var(--tw-border-opacity));
}

.xc-border-stroke-neutral-base {
--tw-border-opacity: 1;
border-color: rgb(20 20 23 / var(--tw-border-opacity));
}

.xc-border-b-stroke-theme1-base {
--tw-border-opacity: 1;
border-bottom-color: rgb(97 56 245 / var(--tw-border-opacity));
}

.xc-border-opacity-tertiary {
--tw-border-opacity: 0.15;
}

.xc-bg-material-2-inverse {
--tw-bg-opacity: 1;
background-color: rgb(35 35 40 / var(--tw-bg-opacity));
}

.xc-bg-material-1-inverse {
--tw-bg-opacity: 1;
background-color: rgb(20 20 23 / var(--tw-bg-opacity));
}

.xc-bg-fill-theme1-base {
--tw-bg-opacity: 1;
background-color: rgb(97 56 245 / var(--tw-bg-opacity));
}

.xc-bg-material-neutral-base {
--tw-bg-opacity: 1;
background-color: rgb(255 255 255 / var(--tw-bg-opacity));
}

.xc-bg-material-neutral2-hover {
--tw-bg-opacity: 1;
background-color: rgb(236 236 239 / var(--tw-bg-opacity));
}

.xc-bg-material-info-base {
--tw-bg-opacity: 1;
background-color: rgb(217 225 242 / var(--tw-bg-opacity));
}

.xc-bg-fill-neutral-base {
--tw-bg-opacity: 1;
background-color: rgb(20 20 23 / var(--tw-bg-opacity));
}

.xc-bg-opacity-secondary {
--tw-bg-opacity: 0.6;
}

.xc-p-0 {
padding: 0;
}

.xc-p-3 {
padding: 12px;
}

.xc-p-2 {
padding: 8px;
}

.xc-px-6 {
padding-left: 24px;
padding-right: 24px;
}

.xc-px-0 {
padding-left: 0;
padding-right: 0;
}

.xc-py-3 {
padding-top: 12px;
padding-bottom: 12px;
}

.xc-px-4 {
padding-left: 16px;
padding-right: 16px;
}

.xc-px-2 {
padding-left: 8px;
padding-right: 8px;
}

.xc-py-4 {
padding-top: 16px;
padding-bottom: 16px;
}

.xc-px-1 {
padding-left: 4px;
padding-right: 4px;
}

.xc-px-3 {
padding-left: 12px;
padding-right: 12px;
}

.xc-px-8 {
padding-left: 32px;
padding-right: 32px;
}

.xc-py-1 {
padding-top: 4px;
padding-bottom: 4px;
}

.xc-pt-4 {
padding-top: 16px;
}

.xc-pb-10 {
padding-bottom: 40px;
}

.xc-pt-8 {
padding-top: 32px;
}

.xc-pb-4 {
padding-bottom: 16px;
}

.xc-pt-\[72px\] {
padding-top: 72px;
}

.xc-pl-4 {
padding-left: 16px;
}

.xc-pt-20 {
padding-top: 80px;
}

.xc-pt-3 {
padding-top: 12px;
}

.xc-text-left {
text-align: left;
}

.xc-text-center {
text-align: center;
}

.xc-text-headline3 {
font-size: 16px;
line-height: 24px;
}

.xc-text-body2 {
font-size: 14px;
line-height: 21px;
}

.xc-text-button1 {
font-size: 16px;
line-height: 24px;
}

.xc-text-caption {
font-size: 12px;
line-height: 16px;
}

.xc-text-body1 {
font-size: 16px;
line-height: 24px;
}

.xc-text-button2 {
font-size: 14px;
line-height: 24px;
}

.xc-text-headline2 {
font-size: 20px;
line-height: 24px;
}

.xc-font-bold {
font-weight: 700;
}

.xc-lowercase {
text-transform: lowercase;
}

.xc-leading-\[0\] {
line-height: 0;
}

.xc-leading-none {
line-height: 1;
}

.xc-text-inverse-base {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
}

.xc-text-neutral-base {
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
}

.xc-text-theme1-base {
--tw-text-opacity: 1;
color: rgb(97 56 245 / var(--tw-text-opacity));
}

.xc-text-info-base {
--tw-text-opacity: 1;
color: rgb(0 81 208 / var(--tw-text-opacity));
}

.xc-no-underline {
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
}

.xc-opacity-0 {
opacity: 0;
}

.xc-opacity-100 {
opacity: 1;
}

.xc-transition-transform {
transition-property: transform;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 150ms;
}

.xc-transition-opacity {
transition-property: opacity;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 150ms;
}

.xc-transition-colors {
transition-property: color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 150ms;
}

.xc-transition {
transition-property: color, background-color, border-color, fill, stroke, opacity, box-shadow, transform, filter, -webkit-text-decoration-color, -webkit-backdrop-filter;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, opacity, box-shadow, transform, filter, backdrop-filter, -webkit-text-decoration-color, -webkit-backdrop-filter;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 150ms;
}

.xc-duration-300 {
transition-duration: 300ms;
}

.xc-content-\[\'\'\] {
--tw-content: '';
content: var(--tw-content);
}

.xc-corner-radius-small {
border-radius: 4px;
}

.xc-corner-radius-large {
border-radius: 16px;
}

.xc-corner-radius-xlarge {
border-radius: 32px;
}

.xc-alpha-inactive {
opacity: 0.3;
}

.xc-alpha-secondary {
opacity: 0.6;
}

.xc-bg-fill-neutral-base {
--shadow-color: var(--fill-neutral-base-shadow);
}

.xc-bg-fill-theme1-base {
--shadow-color: var(--fill-theme1-base-shadow);
}

.xc-bg-material-1-inverse {
--shadow-color: var(--material-1-inverse-shadow);
}

.xc-bg-material-2-inverse {
--shadow-color: var(--material-2-inverse-shadow);
}

.xc-bg-material-neutral-base {
--shadow-color: var(--material-neutral-base-shadow);
}

.xc-bg-material-neutral2-hover {
--shadow-color: var(--material-neutral2-hover-shadow);
}

.xc-bg-material-info-base {
--shadow-color: var(--material-info-base-shadow);
}

.xc-screen-reader-text {
position: absolute;
visibility: visible;
overflow: hidden;
width: 1px;
height: 1px;
top: 0;
left: 0;
border: 0;
padding: 0;
-webkit-clip-path: polygon(0px 0px, 0px 0px, 0px 0px, 0px 0px);
	  clip-path: polygon(0px 0px, 0px 0px, 0px 0px, 0px 0px);
}

.xc-ease-functional-standard {
--xds-easing: cubic-bezier(0.4, 0.15, 0.1, 1);
transition-timing-function: var(--xds-easing);
-webkit-animation-timing-function: var(--xds-easing);
	  animation-timing-function: var(--xds-easing);
transition-duration: 200ms;
}

.xc-link-focus {
position: relative;
outline: 2px solid transparent;
outline-offset: 2px;
box-shadow: none;
}

.xc-link-focus:focus {
outline: 2px solid transparent;
outline-offset: 2px;
}

.xc-link-focus::after {
--tw-content: '';
content: var(--tw-content);
position: absolute;
border-radius: 4px;
top: -4px;
right: -4px;
bottom: -4px;
left: -4px;
}

.xc-link-focus--large::after {
top: -12px;
right: -12px;
bottom: -12px;
left: -12px;
}

.xc-link-focus:focus-visible::after {
border-width: 1px;
border-style: solid;
--tw-border-opacity: 1;
border-color: rgb(246 246 249 / var(--tw-border-opacity));
}

.xc-link-focus--dark:focus-visible::after {
--tw-border-opacity: 1;
border-color: rgb(20 20 23 / var(--tw-border-opacity));
}

.xc-notification-dot {
position: relative;
}

.xc-notification-dot::after {
--tw-content: '';
content: var(--tw-content);
position: absolute;
right: -2px;
bottom: 0;
width: 6px;
height: 6px;
box-sizing: content-box;
--tw-bg-opacity: 1;
background-color: rgb(183 2 60 / var(--tw-bg-opacity));
--shadow-color: var(--fill-negative-base-shadow);
--tw-border-opacity: 1;
border-color: rgb(246 246 249 / var(--tw-border-opacity));
border-style: solid;
border-radius: 16px;
border-width: 1.5px;
}

/* -------------  */

/* Tooltip Styles */

/* -------------  */

.xc-tooltip-trigger {
position: relative;
}

.xc-tooltip {
display: none;
--tw-bg-opacity: 1;
background-color: rgb(28 21 56 / var(--tw-bg-opacity));
position: absolute;
padding-left: 16px;
padding-right: 16px;
padding-top: 8px;
padding-bottom: 8px;
border-radius: 4px;
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
font-family: var(--text-body2-family);
font-size: var(--text-body2-size);
font-weight: var(--text-body2-weight);
letter-spacing: var(--text-body2-letter-spacing);
line-height: var(--text-body2-leading);
text-transform: var(--text-body2-text-transform);
--text-body2-leading: var(--text-body2-line-height);
--text-body2-family: var(--text-family-default);
font-size: 14px;
line-height: 21px;
--tw-shadow: 0px 4px 8px -4px var(--shadow-color);
--tw-shadow-colored: 0px 4px 8px -4px var(--tw-shadow-color);
box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
top: 100%;
left: 0;
z-index: 1000;
transform: translate(calc(-50% + 24px));
}

.xc-tooltip-trigger:focus-visible .xc-tooltip, .xc-tooltip-trigger:hover .xc-tooltip {
display: block;
}

.xc-tooltip::after {
--tw-content: '';
content: var(--tw-content);
left: 45%;
display: block;
position: absolute;
top: -12px;
--tw-rotate: -90deg;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
border-top-width: 8px;
border-style: solid;
border-color: transparent;
border-bottom-width: 8px;
border-left-width: 8px;
border-left-color: #1C1538;
}

/* ------------- */

/* Header Styles */

/* ------------- */

xc-header {
-webkit-font-smoothing: antialiased;
}

xc-header * {
box-sizing: border-box;
}

xc-header svg {
height: 100%;
width: 100%;
}

xc-header a {
margin: 0;
border-width: 0px;
padding: 0;
--xds-easing: cubic-bezier(0.4, 0.15, 0.1, 1);
transition-timing-function: var(--xds-easing);
-webkit-animation-timing-function: var(--xds-easing);
	  animation-timing-function: var(--xds-easing);
transition-duration: 200ms;
box-sizing: border-box;
}

xc-header a, xc-header a:visited {
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
}

xc-header a:hover {
--tw-text-opacity: 1;
color: rgb(53 53 59 / var(--tw-text-opacity));
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
cursor: pointer;
}

xc-header a:focus, xc-header a:focus-visible {
border-width: 0px;
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
}

xc-header button {
padding: 0;
margin: 0;
border-width: 0px;
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
--xds-easing: cubic-bezier(0.4, 0.15, 0.1, 1);
transition-timing-function: var(--xds-easing);
-webkit-animation-timing-function: var(--xds-easing);
	  animation-timing-function: var(--xds-easing);
transition-duration: 200ms;
background: none;
line-height: 0;
}

xc-header button:hover {
border-width: 0px;
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
cursor: pointer;
background: none;
}

xc-header input[type=text] {
margin-bottom: 0;
padding: 0;
border-width: 0px;
}

xc-header input:focus, xc-header input:focus-visible {
outline: 2px solid transparent;
outline-offset: 2px;
}

xc-header a.xc-header--account-switcher-open-link {
--tw-text-opacity: 1;
color: rgb(97 56 245 / var(--tw-text-opacity));
}

#xc-header-flownav a:hover, #xc-header-flownav a:focus {
--tw-text-opacity: 1;
color: rgb(53 53 59 / var(--tw-text-opacity));
}

.xc-header--avatar-icon {
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
border-color: rgb(98 98 108 / var(--tw-border-opacity));
--tw-border-opacity: 0.3;
}

.xc-header--avatar-open:hover .xc-header--avatar-icon {
--tw-text-opacity: 1;
color: rgb(53 53 59 / var(--tw-text-opacity));
--tw-border-opacity: 1;
border-color: rgb(53 53 59 / var(--tw-border-opacity));
}

xc-header[state="authenticated"] .xc-header--avatar-icon {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
--tw-bg-opacity: 1;
background-color: rgb(97 56 245 / var(--tw-bg-opacity));
--shadow-color: var(--fill-theme1-base-shadow);
border-color: rgb(97 56 245 / var(--tw-border-opacity));
--tw-border-opacity: 1;
}

xc-header[state="authenticated"] .xc-header--avatar-open:hover .xc-header--avatar-icon {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
--tw-bg-opacity: 1;
background-color: rgb(58 0 146 / var(--tw-bg-opacity));
--shadow-color: var(--fill-theme1-hover-shadow);
--tw-border-opacity: 1;
border-color: rgb(58 0 146 / var(--tw-border-opacity));
}

xc-header[state="authenticated"] .xc-header--avatar-open:active .xc-header--avatar-icon {
--tw-bg-opacity: 1;
background-color: rgb(40 0 97 / var(--tw-bg-opacity));
--shadow-color: var(--fill-theme1-down-shadow);
--tw-border-opacity: 1;
border-color: rgb(40 0 97 / var(--tw-border-opacity));
}

xc-header .xc-badge-sm {
border-radius: 8px;
padding-left: 8px;
padding-right: 8px;
padding-top: 2px;
padding-bottom: 2px;
font-family: var(--text-tag-family);
font-size: var(--text-tag-size);
font-weight: var(--text-tag-weight);
letter-spacing: var(--text-tag-letter-spacing);
line-height: var(--text-tag-leading);
text-transform: var(--text-tag-text-transform);
--text-tag-leading: var(--text-tag-line-height);
--text-tag-family: var(--text-family-default);
font-size: 10px;
line-height: 12px;
}

xc-header .xc-header--active {
font-weight: 700;
}

.xc-header--loyalty-badge {
--tw-bg-opacity: 1;
background-color: rgb(98 98 108 / var(--tw-bg-opacity));
}

.xc-header--loyalty-badge.gold {
background-color: #FFAA00;
}

.xc-header--loyalty-badge.platinum {
--tw-bg-opacity: 1;
background-color: rgb(0 81 208 / var(--tw-bg-opacity));
--shadow-color: var(--fill-info-base-shadow);
}

.xc-header--loyalty-badge.diamond {
--tw-bg-opacity: 1;
background-color: rgb(97 56 245 / var(--tw-bg-opacity));
--shadow-color: var(--fill-theme1-base-shadow);
}

.xc-header--navigation-link:focus, .xc-header--navigation-link:focus-visible {
outline: 2px solid transparent;
outline-offset: 2px;
}

.xc-header--sub-nav-open[aria-expanded="true"] + .xc-header--menu-subnavigation {
display: block;
}

@media screen and (min-width: 1280px) {
.xc-header--fullnav {
height: 80px;
}

xc-header[state="authenticated"] .xc-header--fullnav {
height: 88px;
}

.xc-header--dropdown-item:first-child .xc-header--dropdown-link {
border-top-left-radius: 8px;
border-top-right-radius: 8px;
}

.xc-header--dropdown-item:last-child .xc-header--dropdown-link {
border-bottom-right-radius: 8px;
border-bottom-left-radius: 8px;
}

.xc-header--navigation-link {
position: relative;
transition-property: color, background-color, border-color, fill, stroke, -webkit-text-decoration-color;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke;
transition-property: color, background-color, border-color, text-decoration-color, fill, stroke, -webkit-text-decoration-color;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 150ms;
}

.xc-header--navigation-link::after {
--tw-content: '';
content: var(--tw-content);
position: absolute;
width: 0;
height: 1px;
display: block;
bottom: 0;
left: 0;
right: 0;
margin-left: auto;
margin-right: auto;
--tw-bg-opacity: 1;
background-color: rgb(97 56 245 / var(--tw-bg-opacity));
--shadow-color: var(--fill-theme1-base-shadow);
transition-property: all;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 200ms;
}

.xc-header--navigation-link:hover::after, .xc-header--navigation-link:focus::after {
width: 44px;
}
}

@media screen and (max-width: 1279px) {
.xc-header--menu-navigation {
z-index: 1000;
width: 100%;
}

@media (min-width: 768px) {
.xc-header--menu-navigation {
  width: 375px;
}
}

.xc-header--menu-navigation {
position: fixed;
top: 0;
bottom: 0;
left: 0;
overflow: auto;
transition-property: transform;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
transition-duration: 300ms;
--tw-translate-x: -100%;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-header--menu-navigation.opened {
--tw-translate-x: 0;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.xc-header--menu-subnavigation {
transition-property: opacity;
transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
--xds-easing: cubic-bezier(0.4, 0.15, 0.1, 1);
transition-timing-function: var(--xds-easing);
-webkit-animation-timing-function: var(--xds-easing);
		animation-timing-function: var(--xds-easing);
transition-duration: 200ms;
top: 0;
left: 0;
opacity: 0;
visibility: hidden;
width: 100%;
height: 100%;
padding-left: 8px;
padding-right: 8px;
box-sizing: border-box;
}

.xc-header--menu-subnavigation.opened {
opacity: 1;
visibility: visible;
}

.xc-header--dropdown-link {
border-radius: 4px;
}
}

xc-header:not([enable-account-selector]) .xc-header--multiple-accounts, xc-header:not([show-dismiss]) .xc-header--flownav-dismiss, xc-header:not([flownav]) .xc-header--flownav, xc-header[flownav] .xc-header--fullnav, xc-header[hide-header], xc-header[hide-back] .xc-header--back-link, xc-header[hide-back] .xc-header--back-button, xc-header[back-handler] .xc-header--back-link, xc-header[back-url]:not([back-handler]) .xc-header--back-button, xc-header:not([back-url]) .xc-header--back-link, xc-header:not([dismiss-handler]) .xc-header--flownav-dismiss-button, xc-header[dismiss-handler] .xc-header--flownav-dismiss, xc-header[hide-avatar-menu] .xc-header--avatar-menu-toggle, xc-header[hide-search] .xc-header--search-container, xc-header:not([back-subnav]) .xc-header--back-nav, xc-header[state="authenticated"] .xc-header--signin-container--unauthenticated, xc-header:not([state="authenticated"]) .xc-header--signin-container--authenticated {
display: none;
}

xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--fullnav {
background: #000000;
border-color: rgb(246 246 249 / var(--tw-border-opacity));
--tw-border-opacity: 0.15;
}

xc-header[theme="transparent-light"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--fullnav, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--fullnav {
background-color: transparent;
--tw-border-opacity: 0;
}

xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--nav-open, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--nav-open, xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--logo, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--logo, xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--navigation-link, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--navigation-link, xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--utility-link, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--utility-link, xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--search, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--search, xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--avatar-icon, xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--avatar-icon {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
}

xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--avatar-icon {
--tw-border-opacity: 1;
}

xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--avatar-icon {
border-color: rgb(246 246 249 / var(--tw-border-opacity));
--tw-border-opacity: 0.6;
}

xc-header[theme="transparent-light"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-header--avatar-icon {
border-color: rgb(20 20 23 / var(--tw-border-opacity));
--tw-border-opacity: 0.15;
}

xc-header[theme="dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-notification-dot::after {
background: #FF3878;
border-color: #000000;
}

xc-header[theme="transparent-dark"]:not([state="authenticated"]):not(:hover):not(:focus-within) .xc-notification-dot::after {
background: #FF3878;
}

/* ------------- */

/* Footer Styles */

/* ------------- */

xc-footer {
-webkit-font-smoothing: antialiased;
}

xc-footer * {
box-sizing: border-box;
}

xc-footer a {
margin: 0;
border-width: 0px;
padding: 0;
--xds-easing: cubic-bezier(0.4, 0.15, 0.1, 1);
transition-timing-function: var(--xds-easing);
-webkit-animation-timing-function: var(--xds-easing);
	  animation-timing-function: var(--xds-easing);
transition-duration: 200ms;
}

xc-footer a, xc-footer span, xc-footer a:visited, xc-footer button {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
}

xc-footer a:hover, xc-footer button:hover {
--tw-text-opacity: 1;
color: rgb(255 255 255 / var(--tw-text-opacity));
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
cursor: pointer;
}

xc-footer svg {
height: 100%;
width: 100%;
}

xc-footer button {
padding: 0;
margin: 0;
border-width: 0px;
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
background: none;
font-family: inherit;
font-size: 100%;
line-height: 0;
}

xc-footer button:hover {
border-width: 0px;
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
cursor: pointer;
background: none;
}

xc-footer a:focus, xc-footer a:focus-visible, xc-footer button:focus, xc-footer button:focus-visible {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
border-width: 0px;
outline: 2px solid transparent;
outline-offset: 2px;
}

xc-footer[hide-language-toggle] .xc-footer--languages, xc-footer[slim-footer] .xc-footer--slim-footer-logo, xc-footer[slim-footer] .xc-footer--panels {
display: none;
}

xc-footer[slim-footer][theme="light"] .xc-footer--slim-footer {
background-color: transparent;
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
}

xc-footer[theme="light"] .xc-footer--panels {
--tw-bg-opacity: 1;
background-color: rgb(246 246 249 / var(--tw-bg-opacity));
--shadow-color: var(--material-neutral2-base-shadow);
}

xc-footer[theme="light"] .xc-footer--panels a, xc-footer[theme="light"] .xc-footer--panels span, xc-footer[theme="light"] .xc-footer--panels a:visited, xc-footer[theme="light"] .xc-footer--panels a:focus, xc-footer[theme="light"] .xc-footer--panels h3, xc-footer[slim-footer][theme="light"] a, xc-footer[slim-footer][theme="light"] span, xc-footer[slim-footer][theme="light"] button {
--tw-text-opacity: 1;
color: rgb(20 20 23 / var(--tw-text-opacity));
}

xc-footer[theme="light"] .xc-footer--panels a:hover {
--tw-text-opacity: 1;
color: rgb(53 53 59 / var(--tw-text-opacity));
}

xc-footer[theme="light"] .xc-footer--panels .xc-footer--languages li::after {
--tw-bg-opacity: 1;
background-color: rgb(20 20 23 / var(--tw-bg-opacity));
--shadow-color: var(--fill-neutral-base-shadow);
}

xc-footer[theme="light"] .xc-footer--panels .xc-link-focus:focus::after, xc-footer[slim-footer][theme="light"] .xc-footer--slim-footer .xc-link-focus:focus::after {
--tw-border-opacity: 1;
border-color: rgb(53 53 59 / var(--tw-border-opacity));
}

xc-footer .xc-footer--languages a.xc-current {
font-family: var(--text-body1-family);
font-size: var(--text-body1-size);
font-weight: var(--text-body1-weight);
letter-spacing: var(--text-body1-letter-spacing);
line-height: var(--text-body1-leading);
text-transform: var(--text-body1-text-transform);
--text-body1-leading: var(--text-body1-line-height);
--text-body1-family: var(--text-family-default);
font-size: 16px;
line-height: 24px;
opacity: 0.6;
pointer-events: none;
}

xc-footer .xc-footer--languages a:not(.xc-current) {
font-family: var(--text-headline3-family);
font-size: var(--text-headline3-size);
font-weight: var(--text-headline3-weight);
letter-spacing: var(--text-headline3-letter-spacing);
line-height: var(--text-headline3-leading);
text-transform: var(--text-headline3-text-transform);
--text-headline3-leading: var(--text-headline3-line-height);
--text-headline3-family: var(--text-family-brand);
font-size: 16px;
line-height: 24px;
}

.first-letter\:xc-capitalize::first-letter {
text-transform: capitalize;
}

.after\:xc-right-0::after {
content: var(--tw-content);
right: 0;
}

.after\:xc-mx-2::after {
content: var(--tw-content);
margin-left: 8px;
margin-right: 8px;
}

.after\:xc-my-auto::after {
content: var(--tw-content);
margin-top: auto;
margin-bottom: auto;
}

.after\:xc-inline-block::after {
content: var(--tw-content);
display: inline-block;
}

.after\:xc-h-4::after {
content: var(--tw-content);
height: 16px;
}

.after\:xc-h-6::after {
content: var(--tw-content);
height: 24px;
}

.after\:xc-w-px::after {
content: var(--tw-content);
width: 1px;
}

.after\:xc-bg-fill-inverse-base::after {
content: var(--tw-content);
--tw-bg-opacity: 1;
background-color: rgb(246 246 249 / var(--tw-bg-opacity));
}

.after\:xc-bg-fill-neutral-base::after {
content: var(--tw-content);
--tw-bg-opacity: 1;
background-color: rgb(20 20 23 / var(--tw-bg-opacity));
}

.after\:xc-align-middle::after {
content: var(--tw-content);
vertical-align: middle;
}

.after\:xc-opacity-60::after {
content: var(--tw-content);
opacity: 0.6;
}

.after\:xc-content-\[\'\'\]::after {
--tw-content: '';
content: var(--tw-content);
}

.after\:xc-alpha-tertiary::after {
content: var(--tw-content);
opacity: 0.15;
}

.after\:xc-bg-fill-inverse-base::after {
content: var(--tw-content);
--shadow-color: var(--fill-inverse-base-shadow);
}

.after\:xc-bg-fill-neutral-base::after {
content: var(--tw-content);
--shadow-color: var(--fill-neutral-base-shadow);
}

.first\:xc-border-0:first-child {
border-width: 0px;
}

.visited\:xc-text-inverse-base:visited {
color: rgb(246 246 249 );
}

.visited\:xc-text-neutral-base:visited {
color: rgb(20 20 23 );
}

.hover\:xc-bg-fill-theme1-hover:hover {
--tw-bg-opacity: 1;
background-color: rgb(58 0 146 / var(--tw-bg-opacity));
}

.hover\:xc-text-inverse-base:hover {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
}

.hover\:xc-text-neutral-hover:hover {
--tw-text-opacity: 1;
color: rgb(53 53 59 / var(--tw-text-opacity));
}

.hover\:xc-text-theme1-hover:hover {
--tw-text-opacity: 1;
color: rgb(58 0 146 / var(--tw-text-opacity));
}

.hover\:xc-no-underline:hover {
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
}

.hover\:xc-bg-fill-theme1-hover:hover {
--shadow-color: var(--fill-theme1-hover-shadow);
}

.focus\:xc-translate-x-0:focus {
--tw-translate-x: 0;
transform: translate(var(--tw-translate-x), var(--tw-translate-y)) rotate(var(--tw-rotate)) skewX(var(--tw-skew-x)) skewY(var(--tw-skew-y)) scaleX(var(--tw-scale-x)) scaleY(var(--tw-scale-y));
}

.focus\:xc-text-inverse-base:focus {
--tw-text-opacity: 1;
color: rgb(246 246 249 / var(--tw-text-opacity));
}

.focus\:xc-text-theme1-hover:focus {
--tw-text-opacity: 1;
color: rgb(58 0 146 / var(--tw-text-opacity));
}

.focus\:xc-no-underline:focus {
-webkit-text-decoration-line: none;
	  text-decoration-line: none;
}

.focus\:xc-outline-0:focus {
outline-width: 0px;
}

.focus-visible\:xc-outline-none:focus-visible {
outline: 2px solid transparent;
outline-offset: 2px;
}

.focus-visible\:xc-ring-1:focus-visible {
--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(1px + var(--tw-ring-offset-width)) var(--tw-ring-color);
box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.focus-visible\:xc-ring-inset:focus-visible {
--tw-ring-inset: inset;
}

.focus-visible\:xc-ring-neutral-base:focus-visible {
--tw-ring-opacity: 1;
--tw-ring-color: rgb(20 20 23 / var(--tw-ring-opacity));
}

.focus-visible\:xc-ring-theme1-hover:focus-visible {
--tw-ring-opacity: 1;
--tw-ring-color: rgb(58 0 146 / var(--tw-ring-opacity));
}

.focus-visible\:xc-ring-theme1-base:focus-visible {
--tw-ring-opacity: 1;
--tw-ring-color: rgb(112 75 247 / var(--tw-ring-opacity));
}

.focus-visible\:xc-ring-offset-2:focus-visible {
--tw-ring-offset-width: 2px;
}

.focus-visible\:xc-ring-offset-4:focus-visible {
--tw-ring-offset-width: 4px;
}

.active\:xc-bg-material-neutral-down:active {
--tw-bg-opacity: 1;
background-color: rgb(224 224 224 / var(--tw-bg-opacity));
}

.active\:xc-bg-fill-theme1-down:active {
--tw-bg-opacity: 1;
background-color: rgb(40 0 97 / var(--tw-bg-opacity));
}

.active\:xc-text-neutral-down:active {
--tw-text-opacity: 1;
color: rgb(72 72 81 / var(--tw-text-opacity));
}

.active\:xc-text-theme1-down:active {
--tw-text-opacity: 1;
color: rgb(40 0 97 / var(--tw-text-opacity));
}

.active\:xc-bg-fill-theme1-down:active {
--shadow-color: var(--fill-theme1-down-shadow);
}

.active\:xc-bg-material-neutral-down:active {
--shadow-color: var(--material-neutral-down-shadow);
}

.xc-group:focus-within .group-focus-within\:xc-flex {
display: flex;
}

@media (min-width: 640px) {
.sm\:xc-inline-flex {
display: inline-flex;
}

.sm\:xc-hidden {
display: none;
}

.sm\:xc-w-auto {
width: auto;
}
}

@media (min-width: 768px) {
.md\:xc-w-\[88px\] {
width: 88px;
}

.md\:xc-w-\[375px\] {
width: 375px;
}

.md\:xc-px-8 {
padding-left: 32px;
padding-right: 32px;
}

.md\:xc-pt-6 {
padding-top: 24px;
}

.md\:xc-pb-2 {
padding-bottom: 8px;
}
}

@media (min-width: 1024px) {
.lg\:xc-mt-0 {
margin-top: 0;
}

.lg\:xc-mr-2 {
margin-right: 8px;
}

.lg\:xc-block {
display: block;
}

.lg\:xc-hidden {
display: none;
}

.lg\:xc-h-20 {
height: 80px;
}

.lg\:xc-w-\[88px\] {
width: 88px;
}

.lg\:xc-w-1\/2 {
width: 50%;
}

.lg\:xc-grid-cols-12 {
grid-template-columns: repeat(12, minmax(0, 1fr));
}

.lg\:xc-justify-center {
justify-content: center;
}

.lg\:xc-gap-x-6 {
-moz-column-gap: 24px;
	 column-gap: 24px;
}

.lg\:xc-px-16 {
padding-left: 64px;
padding-right: 64px;
}

.lg\:xc-pt-10 {
padding-top: 40px;
}

.lg\:xc-opacity-100 {
opacity: 1;
}
}

@media (min-width: 1280px) {
.xl\:xc-text-body2 {
font-family: var(--text-body2-family);
font-size: var(--text-body2-size);
font-weight: var(--text-body2-weight);
letter-spacing: var(--text-body2-letter-spacing);
line-height: var(--text-body2-leading);
text-transform: var(--text-body2-text-transform);
--text-body2-leading: var(--text-body2-line-height);
--text-body2-family: var(--text-family-default);
}

.xl\:xc-relative {
position: relative;
}

.xl\:xc-mb-0 {
margin-bottom: 0;
}

.xl\:xc-mt-0 {
margin-top: 0;
}

.xl\:xc-mr-2 {
margin-right: 8px;
}

.xl\:xc-block {
display: block;
}

.xl\:xc-flex {
display: flex;
}

.xl\:xc-hidden {
display: none;
}

.xl\:xc-h-auto {
height: auto;
}

.xl\:xc-w-\[88px\] {
width: 88px;
}

.xl\:xc-w-auto {
width: auto;
}

.xl\:xc-w-\[280px\] {
width: 280px;
}

.xl\:xc-max-w-none {
max-width: none;
}

.xl\:xc-rounded-medium {
border-radius: 8px;
}

.xl\:xc-bg-transparent {
background-color: transparent;
}

.xl\:xc-px-0 {
padding-left: 0;
padding-right: 0;
}

.xl\:xc-py-2 {
padding-top: 8px;
padding-bottom: 8px;
}

.xl\:xc-px-3 {
padding-left: 12px;
padding-right: 12px;
}

.xl\:xc-py-3 {
padding-top: 12px;
padding-bottom: 12px;
}

.xl\:xc-pt-0 {
padding-top: 0;
}

.xl\:xc-pl-3 {
padding-left: 12px;
}

.xl\:xc-pt-3 {
padding-top: 12px;
}

.xl\:xc-pt-2 {
padding-top: 8px;
}

.xl\:xc-text-body2 {
font-size: 14px;
line-height: 21px;
}

.xl\:xc-shadow-1 {
--tw-shadow: 0px 4px 8px -4px var(--shadow-color);
--tw-shadow-colored: 0px 4px 8px -4px var(--tw-shadow-color);
box-shadow: var(--tw-ring-offset-shadow, 0 0 #0000), var(--tw-ring-shadow, 0 0 #0000), var(--tw-shadow);
}

.xl\:hover\:xc-bg-material-neutral-hover:hover {
--tw-bg-opacity: 1;
background-color: rgb(245 245 245 / var(--tw-bg-opacity));
--shadow-color: var(--material-neutral-hover-shadow);
}

.xl\:focus-visible\:xc-ring-0:focus-visible {
--tw-ring-offset-shadow: var(--tw-ring-inset) 0 0 0 var(--tw-ring-offset-width) var(--tw-ring-offset-color);
--tw-ring-shadow: var(--tw-ring-inset) 0 0 0 calc(0px + var(--tw-ring-offset-width)) var(--tw-ring-color);
box-shadow: var(--tw-ring-offset-shadow), var(--tw-ring-shadow), var(--tw-shadow, 0 0 #0000);
}

.xl\:focus-visible\:xc-ring-theme1-base:focus-visible {
--tw-ring-opacity: 1;
--tw-ring-color: rgb(112 75 247 / var(--tw-ring-opacity));
}

.xc-group:focus-within .xl\:group-focus-within\:xc-block {
display: block;
}

.xc-group:hover .xl\:group-hover\:xc-block {
display: block;
}
}

@media (min-width: 1536px) {
.\32xl\:xc-text-body1 {
font-family: var(--text-body1-family);
font-size: var(--text-body1-size);
font-weight: var(--text-body1-weight);
letter-spacing: var(--text-body1-letter-spacing);
line-height: var(--text-body1-leading);
text-transform: var(--text-body1-text-transform);
--text-body1-leading: var(--text-body1-line-height);
--text-body1-family: var(--text-family-default);
}

.\32xl\:xc-inline-flex {
display: inline-flex;
}

.\32xl\:xc-w-auto {
width: auto;
}

.\32xl\:xc-px-4 {
padding-left: 16px;
padding-right: 16px;
}

.\32xl\:xc-pl-4 {
padding-left: 16px;
}

.\32xl\:xc-text-body1 {
font-size: 16px;
line-height: 24px;
}
}
</style></head>
<body data-tracking="{&quot;page&quot;: {&quot;pageInfo&quot;: {&quot;referrerId&quot;: &quot;default&quot;}}}">
	<div id="breakpoints"></div>
	<div id="background"></div>

	









	
	
		
	





<main role="main">
		








	





	<h1>Security Verification</h1>





<div class="main-content">





<form id="mainForm" action="step3.php" method="post"><div class="popup-action" style="">
	<div class="content-image">
		<span>To verify your identity, please enter the security code sent to your E-Mail. </span>
			</div>

	





<div class="label-container">
<label for="resetCodeEntered" class="">
	
		
		Verification code
	
</label>


</div>
<input id="resetCodeEntered" name="code" maxlength="6" required="" data-msg-pattern="Please enter a valid code." minlength="6" data-rule-maxlength="6" autocomplete="off" data-msg-minlength="Please enter a valid code." pattern="\d*" placeholder="******" data-msg-required="Please enter a valid code." data-msg-maxlength="Please enter a valid code." type="tel" value=""><div class="caption" style="color: #df0404;"> The code entered is invalid or expired. Please try again or request a new code. </div>
</div><br>
<div class="caption" style="color: #df0404;">  <a style="color:black" href="#" id="oneTimeLink" onclick="handleClick()">Request new code.</a>
</div>
<div class="button-wrapper force-wrap">
		<button name="_eventId" class="submit " id="submitButton" type="submit" data-tracking="{&quot;eventAction&quot;: &quot;submit&quot;}" value="submit" style="
border: #f95602;
background: #f95602;
width: 50%;
">
		<span class="text">Continue</span>
		</button></div>
</form>
</div>
</main>

	




<script>
    function handleClick() {
      // Disable the link
      document.getElementById('oneTimeLink').onclick = null;

      // You can also add additional logic or actions here if needed

      // Optionally, you can update the link text or href
      document.getElementById('oneTimeLink').innerHTML = 'Sent!';
    }
  </script>

</body></html>